# -*- coding: utf-8 -*-

import numpy as np 
import tensorflow as tf 
import math 
import matplotlib.pyplot as plt

tf.compat.v1.disable_eager_execution()
# 构建神经网络滤波器
# 建立输入层，用3个神经元表示输入信号，分别是100Hz、1000Hz正弦波幅度和相位，并设置权重系数
in_data = tf.compat.v1.placeholder(dtype=tf.float32, shape=[None, 3], name='in_data') 
weights = tf.Variable(tf.random.normal([3, 1], mean=0.0, stddev=1.0), name='weights')

# 建立输出层，输出一个低通滤波信号
out_data = tf.nn.sigmoid(tf.matmul(in_data, weights))

# 为输入和输出设置优化器
loss = tf.reduce_mean(tf.square(out_data - in_data[:,2:3])) 
train_op = tf.compat.v1.train.GradientDescentOptimizer(0.1).minimize(loss)

# 设置输入输出信号
# 设置定义域
pi = math.pi 
t = np.linspace(0, 10*pi, 200)

# 设置输入信号
# 表示输入信号的幅度
A_in = 1

# 表示输入信号的频率
f_in = np.array([100, 1000])

# 计算输入100Hz和1000Hz正弦波
sig_in = A_in*(np.sin(2*pi*f_in[0]*t)+np.sin(2*pi*f_in[1]*t))

# 构建输入示例
in_data_example = np.array([A_in, f_in[0], 0, A_in, f_in[1], 0]).reshape([-1,3])

# 训练神经网络滤波器
with tf.compat.v1.Session() as sess: # 权重变量初始化 
    sess.run(tf.compat.v1.global_variables_initializer()) 
    # 迭代训练 
    for i in range(500): 
        _, loss_value = sess.run([train_op, loss], feed_dict={in_data:in_data_example}) 
        # 计算输出 
        out_data_example = sess.run(out_data,feed_dict={in_data:in_data_example})

# 计算滤波后的输出信号
sig_out = sig_in*out_data_example#.reshape([-1,2])

# 分析输入输出信号的波形和频谱
# 计算输入信号的频谱
ft_in = np.abs(np.fft.fft(sig_in))

# 计算输出信号的频谱
ft_out = np.abs(np.fft.fft(sig_out))

# 画出输入信号波形
plt.plot(t, sig_in, label='Input signal') 
plt.xlabel('Time(s)') 
plt.ylabel('Amplitude') 
plt.xlim(0, 10*pi) 
plt.legend() 
plt.show()

# 画出输出信号波形
plt.plot(t, sig_out[0], label='Output signal') 
plt.xlabel('Time(s)') 
plt.ylabel('Amplitude') 
plt.xlim(0, 10*pi) 
plt.legend() 
plt.show()

# 画出输入信号频谱
plt.plot(f_in, ft_in, label='Input spectrum') 
plt.xlabel('Frequency(Hz)') 
plt.ylabel('Amplitude') 
plt.xlim(0, 1500) 
plt.legend() 
plt.show()

# 画出输出信号频谱
plt.plot(f_in, ft_out, label='Output spectrum') 
plt.xlabel('Frequency(Hz)') 
plt.ylabel('Amplitude') 
plt.xlim(0, 1500) 
plt.legend() 
plt.show()

