clc,%clear

t = 0:1/5000:0.1;
s = cos(2*pi*100*t)+cos(2*pi*1000*t);
N = 2^nextpow2(5000);
f = 5000/N*(0:1:N-1);

subplot(3, 2, 1);
plot(t, s, 'b');
title("original signal");xlabel('t/s');

A = abs(fft(s, N)/N*2);
subplot(3, 2, 2);
plot(f(1:N/2), A(1:N/2), 'r');
title("original signal spectrum"); xlabel('f/Hz');

ylp = filter(LPF, s);
subplot(3, 2, 3);
plot(t, ylp, 'b');
title("LPF signal");xlabel('t/s');

A = abs(fft(ylp, N)/N*2);
subplot(3, 2, 4);
plot(f(1:N/2), A(1:N/2), 'r');
title("LPF signal spectrum"); xlabel('f/Hz');

yhp = filter(HPF, s);
subplot(3, 2, 5);
plot(t, yhp, 'b');
title("HPF signal");xlabel('t/s');


A = abs(fft(yhp, N)/N*2);
subplot(3, 2, 6);
plot(f(1:N/2), A(1:N/2), 'r');
title("HPF signal spectrum"); xlabel('f/Hz');